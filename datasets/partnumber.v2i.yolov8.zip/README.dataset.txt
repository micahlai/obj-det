# partnumber > 2024-07-18 9:32am
https://universe.roboflow.com/seiji/partnumber-jzh7a

Provided by a Roboflow user
License: CC BY 4.0

